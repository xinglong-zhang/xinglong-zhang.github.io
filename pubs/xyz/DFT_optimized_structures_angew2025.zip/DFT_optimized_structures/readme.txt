This folder contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper

"Enantioselective Synthesis of Sulfinimidate Esters by Sulfinamide Activation Approach"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

The following are subfolders
/gas_phase/ -- DFT structures in the gas phase optimization (main methodology used in the paper)
/solv_phase/ -- DFT structures in the solvation phase optimization (for the study of ammonium intermediate formation step)

