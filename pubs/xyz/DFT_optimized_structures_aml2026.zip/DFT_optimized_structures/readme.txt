This folder /DFT_optimized_structures/ contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper

"Locking of CO2 in a Bio-inspired Porous-Organic-Polymeric Prison: Impact of Aliphatic Odd-Even Linker Combination"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

