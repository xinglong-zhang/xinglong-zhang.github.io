This folder /xyz_structures/ contains the geometries (in .xyz format together with the gas-phase energy, E) 

accompanying the paper
"Paper Title"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

This folder has the following structure and they correspond to the raw data in the SI:


/DFT_optimized_structures/ 
    --> contains DFT-optimized structures for the computational study of the mechanism for the reaction between intermediates IV-3b/IV-3ac and isatin substrate 2b.

/DI-AS_analysis/ 
    --> structures along the IRC pathways for Si-ts1 (in subfolder /Si-ts1/) and Re-ts1 (in subfolder /Re-ts1/) taken for distortion interaction-activation strain (DI-AS) model analysis.
    --> structures along the IRC points are named p<num>.xyz where <num> denotes number of points along the IRC from the TS; fragments results from each point are denoted p<num>_f1.xyz and p<num>_f2.xyz. For example, the first point along the IRC is named p1.xyz and its component fragments are denoted p1_f1.xyz and p2_f2.xyz.
 
