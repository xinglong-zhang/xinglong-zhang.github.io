This folder TS_xyz contains all the TS structures from conformational sampling in .xyz format accompanying the paper

"Post-Translational Site-selective Protein α-Deuteration: Protein Backbone Modification and Use as a Tool for Protein Mechanism" by Galan et al.


Two subfolders, indicated by the identity of the base used int the studies, with the following substructures, can be found:

                     
                         |------ THTCD_deprotonation: all TSs from deprotonation of tetrahydrothiophene ring
                         | 
1_hydroxide_base --------|------ intramolecular deprotonation: all TSs from intramolecular deprotonation by sulfonium ylid
                         |
                         |------ E2_deprotonation: all TSs from deprotonation of alpha-carbon of cysteine
                         |
                         |------ sulfonium_ylid_deprotonation: all TSs from sulfonium ylid decomposition via cycloreversion



                                    |------ THTCD_deprotonation: lowest (and the only found) TS for deprotonation of tetrahydrothiophene ring 
                                    | 
2_dihydrogen_phosphate_base --------|
                                    |
                                    |------ E2_deprotonation: all TSs from deprotonation of alpha-carbon of cysteine
