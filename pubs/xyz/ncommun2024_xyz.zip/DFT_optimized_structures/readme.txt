This folder contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper
"Carbene Catalysed Chirality-Controlled Site-Selective Acylation of Saccharides"
Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

This folder contains the following subfolders:
/NHC_G/ --> DFT optimized structures for the study of NHC carbene G (entry 9, Table 1)
/NHC_entG/ --> DFT optimized structures for the study of NHC carbene ent-G (entry 17, Table 1)
