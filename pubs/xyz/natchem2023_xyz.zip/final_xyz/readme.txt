This folder /final_xyz/ contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper

"Access to Bicyclic Unsaturated Lactones via Remote Methylene C(sp3)–H Activation"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

