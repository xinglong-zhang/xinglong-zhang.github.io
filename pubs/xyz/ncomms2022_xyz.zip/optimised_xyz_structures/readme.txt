This folder /optimized_xyz_structures/ contains the geometries (in .xyz format together with the gas-phase energy, E) 

accompanying the paper
"Atroposelective Synthesis of Axially Chiral Aryl Nitriles"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1, c2, ...

This folder has the following structure and they correspond to the raw data in the SI:


/full_system/ 
    --> contains DFT-optimized structures for the computational study of the key rate-determining step of the full system used in the experimental study. 
/model_system/ 
    --> contains DFT-optimized structures for the model system used in the computational study of the reaction mechanism. 
