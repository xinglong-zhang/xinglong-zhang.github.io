This folder contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper

"Theoretical Studies on Anhydride Dynamic Covalent Bond Exchange Mechanism: Uncatalysed or Acid-catalysed?"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

/MAA_and_PNA/ -- DFT structures from the study of anhydride exchange beween methacrylic anhydride (MAA) and 4-pentenoic anhydride (PNA)
    |----/acid_catalysis/ -- DFT structures from M06-2X/def2-SVP level of theory optimization in gas phase for acid catalyzed mechanism
    |----/gas_def2/ -- DFT structures from M06-2X/def2-SVP level of theory optimization in gas phase
    |----/gas_def2_irc/ -- IRC movies of the TS for the concerted mechanism with and without acid at M06-2X/def2-SVP level of theory in gas phase
    |----/gas_pople/ -- DFT structures from M06-2X/6-31G+(d) level of theory optimization in gas phase
    |----/solv_opt/ -- DFT structures from SMD(CHCl3)-M06-2X/def2-SVP level of theory optimization in implicit chloroform solvent phase
    |----/m062xd3/ -- DFT structures from M06-2X-D3/def2-SVP level of theory optimization in gas phase

