This folder contains the xTB-optimized geometries (in .xyz format) accompanying the paper

"Asymmetric Ion-Pairing Catalysis in Water Enabled by DNA Phosphates"

Where conformers occur, they are always named from the lowest single-point DFT energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

This folder contains the following subfolders:

/Fluorination/ --> xTB-optimized structures for fluorination reaction

/Mannich_reaction/ --> xTB-optimized structures for Mannich reaction
