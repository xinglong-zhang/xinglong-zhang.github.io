This folder /DFT_xyz_structures/ contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper

"Atroposelective Access to 1,3-Oxazepine-Containing Bridged Biaryls via Carbene-Catalyzed Desymmetrization of Imines"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

This folder contains the following sub-folders:
- /irc_movies/ contains movies of the IRC analyses for the rotational barrier TSs;
- /reaction/ contains the DFT-optimized conformers of azolium intermediate and the TSs for the enantio-determining step;
- /rotation/ contains the conformers of structure 5 and the TSs for the enantiomerization
