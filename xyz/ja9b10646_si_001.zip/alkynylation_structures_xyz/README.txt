This folder contains the Gaussian output files (in .xyz format) of the study of Pd-catalysed alkynylation
entitled "An Alkyne Linchpin Strategy for Drug:Pharmacophore Conjugation: Experimental and Computational Realization of a meta-selective Inverse Sonogashira Coupling"

The folder structure is organised as below:

/0_sm/: starting materials for the reactions

/1_alkynylation_of_1b/: alkynylation reaction using substrate 1b, including regioconvergence studies

/2_alkynylation_of_1b_aa_ligand/: alkynylation (C-H activation and 1,2-migratory insertion) reaction using MPAA ligand instead of acetate

/3_alkynylation_of_1b_copper/: alkynylation involving Cu(OAc)2 additive

/4_arene_site_selectivity_ortho_para/: site selectivity studies for C-H activation

/5_alternative_oxidative_addition_TSs/: oxidative addition TSs that all have higher activation barriers that 1,2-migratory insertion TSs

/6_ethynyltrimethylsilane_1c/: alkynylation reaction using substrate 1c, including regioconvergence studies

/7_bromoethynylbenzene_1d/: alkynylation reaction using substrate 1d, including regioconvergence studies

/8_other_substrates/: alkynylation reaction using 
  - substrates  1e-1h (TIPS-, TBDMS-, TES-alkynyl bromide and siloxy-substituted alkynyl bromide), 
  - arene substrates 4, 5, 12 having different substituents
  - substrates for products 17-19 with different DG tether lengths
including regioconvergence studies
