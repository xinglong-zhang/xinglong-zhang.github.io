This folder contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper

"Kinetically controlled Z-selective catalytic allene dialkylation"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

