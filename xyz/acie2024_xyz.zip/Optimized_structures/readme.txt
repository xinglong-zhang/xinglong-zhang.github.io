The folder /DFT_structures/ contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper

"Ionic Hydrogen Bond-Assisted Catalytic Construction of Nitrogen Stereogenic Center via Formal Desymmetrization of Remote Diols"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, .., etc.

The folder /xTB_structures/ contain structures crest_best_major_full_F.xyz and crest_best_minor_full_F.xyz, which are the most stable GFN2-xTB optimized structures from CREST conformational sampling while constraining the model system with chiral phosphoric acid C-3 added to the system.
