This folder contains the optimised structures of the study of Pd-catalysed delta-sp3 C-H arylation accompanying the paper titled
<Iterative Arylation of Amino Acids and Aliphatic Amines via delta-C(sp3)-H Activation: Experimental and Computational Exploration>

The folder structure is organised as below:

1. /substrate_2a/ containing the following subfolders:
   1.1 /0_sm/ (starting materials for the reaction using substrate 2a)

   1.2 /1_no_ligand/ (structures for pathway without ligand) 
       1.2.1 /lowest_conformers/ (structures used in the paper)
       1.2.2 /other_conformers/ (other conformers considered)
  
   1.3 /2_pyridine_ligand/ (structures for pathway with pyridine ligand L1) 

   1.4 /3_reductive_elimination_TSs/ (other reductive elimination TSs considered)
       1.3.1 /I_ligand/ (reductive elimination TSs with I-ligand)
       1.3.2 /TFA_ligand/ (reductive elimination TSs with TFA-ligand replacing I-ligand)

   1.5 /4_silver_carbonate_coligand/ (structures with silver carbonate co-ligand)

   1.6 /5_DG_studies/ (directing group studies)


2. /substrate_3a/
   2.1 /0_sm/ (starting materials for the reaction using substrate 1b)
   
   2.2 /1_no_ligand/ (structures for pathway without ligand using substrate 1b) 
 
   2.3 /2_pyridone_ligand/ (structures for pathway with pyridone ligand L2) 

   2.4 /3_other_conformers/ (other conformers considered for the reaction TSs)

   2.5 /4_silver_carbonate_coligand/ (structures with silver carbonate co-ligand)
   
   2.6 /5_cationic_OA/ 
       2.6.1 /Ag/ structures involving Ag+ cations for oxidative addition step
       2.6.2 /Na/ structures involving Na+ cations for oxidative addition step
   2.7 /6_CH_activation_TSs/ (TS structures for all C-H activation possibilities)
     
3. /substrate_4a/ (TS structures from regioselectivity study of substrate 4a)
   
4. /substrate_5a/ (TS structures from regioselectivity study of substrate 5a)

5. /substrate_6a/ (TS structures from regioselectivity study of substrate 6a)

6. /substrate_7a/ (TS structures from regioselectivity study of substrate 7a)

7. /isodesmic_reaction/ (opt structures for pyridine-coordinated CH activated complexes from 2a and 3a)
