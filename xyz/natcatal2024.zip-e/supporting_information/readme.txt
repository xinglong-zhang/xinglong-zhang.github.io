This folder /final_xyz/ contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper

"Congested C(sp3)-rich architectures enabled by iron-catalyzed conjunctive alkylation"

Where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

This folder contains the following subfolders:

/DFT_structures/ --> DFT optimized structures

/Mulliken_spin_population_logfiles/  --> Gaussian .log output files for the insertion step where Mulliken spin populations can be visualized in the triplet and quintet spin states.

/movies/  --> movies for the TSs for insertion and reductive elimination step and the associated intrinsic reaction coordinate (IRC) movies.

