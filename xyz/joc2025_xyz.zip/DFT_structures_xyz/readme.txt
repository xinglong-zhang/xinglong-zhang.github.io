This folder contains the DFT-optimized geometries (in .xyz format together with the gas-phase energy, E) accompanying the paper

"Unravelling the Mechanism and Influence of Auxiliary Ligands on the Isomerization of Neutral [P,O]‐Chelated Nickel Complexes for Olefin Polymerization: Insights from Computational DFT Studies"

where conformers occur, they are always named from the lowest Gibbs energy to the highest in ascending order from c1 (sometimes omitted), c2, c3, ...

Folder structure:
--/ligands/ contains DFT optimized structures of auxiliary ligands L1-L5
--/XIII/ contains optimized DFT structures and constrained optimized DFT structures for catalyst system XIII
--/XIV/ contains optimized DFT structures and constrained optimized DFT structures for catalyst system XIV
--/first_polymerization_step/ contains optimized DFT structures for the first polymerization step (ethylene and acrylate enchainment) catalyzed by system XIII
